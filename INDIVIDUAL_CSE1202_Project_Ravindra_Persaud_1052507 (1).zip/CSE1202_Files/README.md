# Trigon Raid
A space shooter game with predictive enemy movement and wave-based progression.

# Link to Recording 
https://drive.google.com/drive/folders/1YrVUoyKhudPJPKvDwOKb70k-_RUUocC5?usp=sharing

## 🎮 Features 

- **Dynamic Gameplay**: Enemies can evade shots and maneuver in complex patterns.
- **Wave System**: Growing enemy strength, speed, and numbers in an ascending manner
- **Scoring System**: Kills, power shot hits, and wave completion all earn points.
- **Power Shots**: Special attacks that deal more damage
- **Health**: Numerical health indicators and visual health bars
- **Starfield Background**: Background featuring stars

## 🕹️ Controls

- **Arrow Keys**: Move the player ship
- **Space**: Fire shots at enemy ships (automatically switches between ordinary shots and power shots)
- **R**: Restart game 
- **ESC**: Quit game

##  Game Mechanics

## Player
- Begins with 150 health
- Can move in any direction within the window 
- Regular shots (15 damage) and power shots (30 damage)
- Power shots have a 2-second intervals before being able to use it again

## Enemies
- 100 health
- Move in complex patterns 
- Can dodge player shots
- Fire shots at the player
- Health and speed increases with each wave

## Scoring
- Enemy kills: 100 points
- Power shot kill bonus: 50 points
- Wave completion bonus: 200 points

### Waves
- Each wave increases in difficulty
- Enemy health increases by 20 per wave (Stops at 200)
- Enemy speed increases with each wave
- Number of enemies increases up to 8 maximum


## Requirements
- Python 
- Pygame
- NumPy

## Installation

1. Clone the repository
2. Install required packages:
    pip install pygame numpy

## Credits and Asset Attribution

**Sprites**
Space Shooter Extension by Kenney (www.kenney.nl)
Rocket sprites: spaceRockets_001.png
Enemy sprites: spaceShips_002.png
Projectile sprites: spaceMissiles_001.png
source: Kenney Space Shooter Extension
License: CC0 1.0 Universal
Website:
http://kenney.nl/assets/ui-pack

**Sound Effects**

Sci-Fi Sounds by Kenney (www.kenney.nl)
Laser sounds: laserSmall_001.ogg, laserLarge_001.ogg
Explosion sounds: explosionCrunch_001.ogg
Impact sounds: impactMetal_001.ogg
Source: Kenney Sci-Fi Sounds
License: CC0 1.0 Universal 
Website:
https://kenney.nl/assets/onscreen-controls