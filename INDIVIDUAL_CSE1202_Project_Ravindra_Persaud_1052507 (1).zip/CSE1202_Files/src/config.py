"""
Constants and game setup.
To facilitate simple game adjustments, balance, and design change, all essential settings, 
constants, and resource pathways have been compiled into this file.
"""

# Screen and Display settings
WIDTH = 800
HEIGHT = 600
TITLE = "Trigon Raid"
FPS = 60

# Colors definitions
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
BLACK = (0, 0, 0)
YELLOW = (255, 255, 0)

# Player configuration
PLAYER_MAX_HEALTH = 150 # Maximum HP.
PLAYER_SPEED = 5
PLAYER_SHOT_DELAY = 250  # Regular shot cooldown in milliseconds.
PLAYER_POWER_SHOT_DELAY = 2000  # Power shot cooldown in milliseconds.
PLAYER_INVULNERABILITY_DURATION = 60  # Frames of invulnerability after being hit.
PLAYER_START_Y = 100  # Distance from bottom of screen.

# Enemy configuration
ENEMY_MAX_HEALTH = 200 # Maximum HP for enemies
ENEMY_BASE_SPEED = 2    # default speed for enemies
ENEMY_SPEED_RANGE = (2, 4)
ENEMY_SHOOT_DELAY_RANGE = (1000, 2000)
ENEMY_SHOOT_SPEED = 7
ENEMY_SPAWN_Y_RANGE = (50, 200)
ENEMY_EVASION_DISTANCE = 100 # How close a shot can get before enemy dodges it.
ENEMY_MARGIN = 40  # Screen margin for movement

# Projectile congiguration
PROJECTILE_DAMAGE = 25 # damage of regular shots
PROJECTILE_SPEED = 10  # Speed of regular shots
POWER_SHOT_SPEED = 8  # Speed of power shots
POWER_SHOT_MIN_DAMAGE = 50 # lowest damage for power shots
POWER_SHOT_SIZE = (12, 40) # Size of power shots
REGULAR_SHOT_SIZE = (4, 20) # Size of regular shots

# Scoring System
ENEMY_KILL_SCORE = 100 # score for killing an enemy
POWER_SHOT_KILL_BONUS = 50 # bonus points for killing an enemy with a power shot
WAVE_COMPLETION_BONUS = 200 # bonus points for completing a wave of enemies

# Wave System
MAX_WAVES = 10  # Total number of waves
INITIAL_ENEMIES = 3 # default number of enemies per wave
MAX_ENEMIES = 8 # Maximum number of enemies per wave
WAVE_ENEMY_INCREASE = 1 # Number of enemies to add per wave
WAVE_HEALTH_INCREASE = 0.2  # 20% increase per wave
WAVE_SPEED_INCREASE = 0.1   # 10% increase per wave

def calculate_wave_difficulty(wave_number):
    """
    Determines wave difficulty using number theory:
    - Uses prime factors for non-linear scaling
    - Applies modulo arithmetic for wave patterns
    - Uses GCD for timing calculations
    """
    # Base difficulty increases
    base_health = 1 + (wave_number * WAVE_HEALTH_INCREASE)
    base_speed = 1 + (wave_number * WAVE_SPEED_INCREASE)
    
    # Prime factor bonus
    prime_factors = []
    n = wave_number
    while n % 2 == 0:
        prime_factors.append(2)
        n = n // 2
    i = 3
    while i * i <= n:
        while n % i == 0:
            prime_factors.append(i)
            n = n // i
        i += 2
    if n > 2:
        prime_factors.append(n)
    
    # Apply prime factor bonuses
    health_multiplier = base_health * (1 + len(prime_factors) * 0.1)
    speed_multiplier = base_speed * (1 + sum(prime_factors) * 0.05)
    
    # Modulo-based pattern variations
    pattern_mod = wave_number % 2
    if pattern_mod == 0:
        health_multiplier *= 1.2  # Stronger enemies every 2 waves
    elif pattern_mod == 1:
        speed_multiplier *= 1.2   # Faster enemies every 2 waves + 1
    
    return health_multiplier, speed_multiplier

# Visual Effects
EXPLOSION_DURATION = 20
HIT_EFFECT_DURATION = 10
EXPLOSION_SIZE = (120, 120)
SMALL_EXPLOSION_SIZE = (60, 60)
HIT_EFFECT_SIZE = (40, 40)
POWER_SHOT_EFFECT_SIZE = (40, 40)
POWER_SHOT_TRAIL_LENGTH = 3
POWER_SHOT_TRAIL_SPACING = 15
POWER_SHOT_TRAIL_FADE_STEP = 70

# Background
NUM_STARS = 50
STAR_SPEED_RANGE = (1, 3)
STAR_SIZE_RANGE = (1, 2)

# Asset Paths
PLAYER_SPRITE = "assets/kenney_space-shooter-extension/PNG/Sprites/Rockets/spaceRockets_001.png"
DRONE_SPRITE = "assets/kenney_space-shooter-extension/PNG/Sprites/Ships/spaceShips_002.png"
PROJECTILE_SPRITE = "assets/kenney_space-shooter-extension/PNG/Sprites/Missiles/spaceMissiles_001.png"

# Effect Sprite Paths
EXPLOSION_SPRITE = "assets/kenney_space-shooter-extension/PNG/Sprites/Effects/spaceEffects_013.png"
SMALL_EXPLOSION_SPRITE = "assets/kenney_space-shooter-extension/PNG/Sprites/Effects/spaceEffects_014.png"
IMPACT_SPRITE = "assets/kenney_space-shooter-extension/PNG/Sprites/Effects/spaceEffects_004.png"
POWER_SHOT_EFFECT = "assets/kenney_space-shooter-extension/PNG/Sprites/Effects/spaceEffects_017.png"
HIT_EFFECT = "assets/kenney_space-shooter-extension/PNG/Sprites/Effects/spaceEffects_002.png"

# Sound Paths
LASER_SOUND = "assets/kenney_sci-fi-sounds/Audio/laserSmall_001.ogg"
EXPLOSION_SOUND = "assets/kenney_sci-fi-sounds/Audio/explosionCrunch_001.ogg"
IMPACT_SOUND = "assets/kenney_sci-fi-sounds/Audio/impactMetal_001.ogg"
POWER_SHOT_SOUND = "assets/kenney_sci-fi-sounds/Audio/laserLarge_001.ogg"

# UI Settings
FONT_SIZE = 36
HEALTH_BAR_WIDTH = 100
HEALTH_BAR_HEIGHT = 10
SCORE_POSITION = (200, 8)
HEALTH_BAR_POSITION = (10, 10)
HEALTH_TEXT_POSITION = (120, 8)
WAVE_TEXT_POSITION = (WIDTH // 2, 8)
CONTROLS_TEXT_POSITION = (WIDTH // 2, HEIGHT - 30) 