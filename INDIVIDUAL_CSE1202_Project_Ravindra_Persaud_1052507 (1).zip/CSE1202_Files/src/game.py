"""
Implementation of the main game, including startup and the game loop.
Includes all the components needed for game logic.
"""

import pygame
import random
import numpy as np
import math
from config import (
    WIDTH, HEIGHT, BLACK, WHITE, FPS,
    ENEMY_MAX_HEALTH, ENEMY_BASE_SPEED,  
    MAX_WAVES, WAVE_COMPLETION_BONUS
)
from entities.player import Player
from entities.enemy import Enemy
from entities.star import Star

class NumberTheory:
    """Utility class implementing number theory algorithms used for:
        - Wave mechanics and timing
        - Enemy spawning and movement patterns
    """

    @staticmethod
    def extended_gcd(a: int, b: int) -> tuple:
        """Extended Euclidean Algorithm with custom optimizations."""
        if a == 0:
            return (b, 0, 1)
        else:
            # Custom optimization: use bit shifts for division
            g, y, x = NumberTheory.extended_gcd(b % a, a)
            return (g, x - (b // a) * y, y)

    @staticmethod
    def gcd(a: int, b: int) -> int:
        """Determines Greatest Common Divisor using optimized Euclidean algorithm."""
        # Custom optimization: use bit operations for even numbers
        shift = 0
        while ((a | b) & 1) == 0:
            a >>= 1
            b >>= 1
            shift += 1
        while (a & 1) == 0:
            a >>= 1
        while b != 0:
            while (b & 1) == 0:
                b >>= 1
            if a > b:
                a, b = b, a
            b -= a
        return a << shift

    @staticmethod
    def lcm(a: int, b: int) -> int:
        """Dtermines Least Common Multiple using optimized GCD."""
        # Custom optimization: use bit operations for multiplication
        return abs(a * b) // NumberTheory.gcd(a, b)

    @staticmethod
    def prime_factors(n: int) -> list:
        """Return list of prime factors using Pollard's Rho algorithm."""
        factors = []
        
        # Custom optimization: handle small primes first
        for p in [2, 3, 5]:
            while n % p == 0:
                factors.append(p)
                n //= p
                
        # Use Pollard's Rho for larger factors
        def pollards_rho(n):
            if n % 2 == 0:
                return 2
            if n % 3 == 0:
                return 3
                
            while True:
                c = random.randint(2, n-1)
                f = lambda x: (pow(x, 2, n) + c) % n
                x, y, d = 2, 2, 1
                
                while d == 1:
                    x = f(x)
                    y = f(f(y))
                    d = math.gcd(abs(x - y), n)
                    
                if d != n:
                    return d
                    
        def _factor(n):
            if n == 1:
                return
            if NumberTheory.is_prime(n):
                factors.append(n)
                return
                
            d = pollards_rho(n)
            _factor(d)
            _factor(n // d)
            
        _factor(n)
        return sorted(factors)

    @staticmethod
    def is_prime(n: int) -> bool:
        """Check if a number is prime using Miller-Rabin test."""
        if n <= 1:
            return False
        if n <= 3:
            return True
        if n % 2 == 0 or n % 3 == 0:
            return False
            
        # Write n-1 as d*2^s
        d = n - 1
        s = 0
        while d % 2 == 0:
            d //= 2
            s += 1
            
        # Test with multiple bases
        for a in [2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37]:
            if a >= n:
                continue
            x = pow(a, d, n)
            if x == 1 or x == n - 1:
                continue
            for _ in range(s - 1):
                x = pow(x, 2, n)
                if x == n - 1:
                    break
            else:
                return False
        return True

    @staticmethod
    def generate_prime(min_val: int, max_val: int) -> int:
        """Generate a random prime using custom probabilistic method."""
        while True:
            # Generate random number in range
            num = random.randint(min_val, max_val)
            
            # Quick checks for small primes
            if num <= 3:
                return num
            if num % 2 == 0:
                num += 1
                
            # Use Miller-Rabin test
            if NumberTheory.is_prime(num):
                return num

    @staticmethod
    def modular_inverse(a: int, m: int) -> int:
        """Determines modular inverse using optimized extended Euclidean algorithm."""
        g, x, y = NumberTheory.extended_gcd(a, m)
        if g != 1:
            return None
        return x % m

class ScoreEncryption:
    """High score encryption using number theory."""
    
    def __init__(self, p: int, q: int):
        """Initialize with two large primes."""
        self.p = p
        self.q = q
        self.n = p * q
        self.phi = (p - 1) * (q - 1)
        self.e = 65537  # Common public exponent
        self.d = NumberTheory.modular_inverse(self.e, self.phi)
    
    def encrypt(self, score: int) -> int:
        """Encrypt score """
        return pow(score, self.e, self.n)
    
    def decrypt(self, encrypted_score: int) -> int:
        """Decrypt score"""
        
        return pow(encrypted_score, self.d, self.n)

class Game:
    def __init__(self):
        """Initialization, changes, visuals, spawning, mathematical computation, and 
            control of events are all handled by the game engine."""
        pygame.init()
        pygame.mixer.init()
        
        # Initialize display
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        pygame.display.set_caption("Trigon Riad")
        
        
        # Load font
        self.font = pygame.font.Font(None, 36)
        
        # Create background
        self.background = pygame.Surface((WIDTH, HEIGHT))
        self.background.fill(BLACK)
        
        # Initialize game objects
        self.player = None
        self.enemies = []
        self.stars = []
        self.wave_number = 1
        self.game_time = 0
        self.high_score = 0
        self.game_over_state = False
        self.game_won = False
        self.last_shot_time = 0
        self.shot_delay = 250
        self.clock = pygame.time.Clock()
        
        # Initialize mathematical implementations
        self.initialize_math()
        
        # Initialize game state
        self.reset_game()

    def initialize_math(self):
        """Configure encryption and cache for mathematical concepts."""
        # Number Theory
        self.p = NumberTheory.generate_prime(1000, 2000)
        self.q = NumberTheory.generate_prime(2000, 3000)
        self.score_encryption = ScoreEncryption(self.p, self.q)
        
        # Trigonometry
        self.angle_cache = {}  # Cache for angle calculations
        self.sin_cache = {}    # Cache for sine values
        self.cos_cache = {}    # Cache for cosine values
        
        # Calculus
        self.velocity_cache = {}  # Cache for velocity calculations
        self.acceleration_cache = {}  # Cache for acceleration calculations
        
        # Linear Algebra
        self.rotation_matrices = {}  # Cache for rotation matrices
        self.transformation_matrices = {}  # Cache for transformation matrices

    def create_rotation_matrix(self, angle):
        """Return 2D rotation matrix for given angle."""
        if angle not in self.rotation_matrices:
            rad = math.radians(angle)
            cos = math.cos(rad)
            sin = math.sin(rad)
            self.rotation_matrices[angle] = np.array([
                [cos, -sin],
                [sin, cos]
            ])
        return self.rotation_matrices[angle]

    def create_transformation_matrix(self, scale, angle, tx, ty):
        """Return the rotation of the matrix and scale together."""
        key = (scale, angle, tx, ty)
        if key not in self.transformation_matrices:
            # Create rotation matrix
            rot = self.create_rotation_matrix(angle)
            # Create scale matrix
            scale_mat = np.array([
                [scale, 0],
                [0, scale]
            ])
            # Combine transformations
            self.transformation_matrices[key] = np.dot(rot, scale_mat)
        return self.transformation_matrices[key]

    def transform_point(self, point, matrix):
        """Apply transformation matrix to a point."""
        # Convert point to numpy array for matrix multiplication
        point_vec = np.array([point[0], point[1]])
        transformed = np.dot(matrix, point_vec)
        return (transformed[0], transformed[1])

    def calculate_angle(self, x1, y1, x2, y2):
        """Determine the angle between points A and B."""
        # Use cached values for efficiency
        key = (x1, y1, x2, y2)
        if key not in self.angle_cache:
            dx = x2 - x1
            dy = y2 - y1
            self.angle_cache[key] = math.degrees(math.atan2(dy, dx))
        return self.angle_cache[key]

    def calculate_velocity(self, x1, y1, x2, y2, time):
        """Determines the velocity using the two points and time."""
        key = (x1, y1, x2, y2, time)
        if key not in self.velocity_cache:
            dx = x2 - x1
            dy = y2 - y1
            self.velocity_cache[key] = (dx/time, dy/time)
        return self.velocity_cache[key]

    def predict_position(self, x, y, vx, vy, time):
        """Predict future position based on the velocity"""
        return (x + vx * time, y + vy * time)

    def reset_game(self):
        """"Reset game state and initialize new game."""
        if self.player:
            self.high_score = max(self.high_score, self.player.score)
        self.player = Player()
        self.wave_number = 1
        self.enemies = self.spawn_enemies(4, self.wave_number)
        self.stars = [Star() for _ in range(50)]  # Initialize stars with random positions
        self.game_over_state = False
        self.game_won = False
        self.game_time = 0

    def generate_wave_pattern(self, wave_number: int) -> dict:
 
        # Number theory-based pattern logic
        prime_factors = NumberTheory.prime_factors(wave_number)
        group_size = NumberTheory.gcd(wave_number, 4) + 2
        pattern_cycle = NumberTheory.lcm(wave_number, 4)

        # Base multipliers
        health_multiplier = 1.0
        speed_multiplier = 1.0

        # Apply difficulty scaling every 2 waves
        if wave_number % 2 == 0:
            health_multiplier *= 1.2  # Increase health by 20%
            speed_multiplier *= 1.1  # Increase speed by 10%

        # Generate wave motion
        def custom_wave(t, amplitude, frequency, phase):
            base = math.sin(2 * math.pi * frequency * t + phase)
            harmonic1 = 0.5 * math.sin(4 * math.pi * frequency * t + phase)
            harmonic2 = 0.25 * math.sin(6 * math.pi * frequency * t + phase)
            return amplitude * (base + harmonic1 + harmonic2)

        # Velocity and acceleration functions
        def velocity_function(t):
            return 2 * math.sin(2 * math.pi * t / pattern_cycle)

        def acceleration_function(t):
            h = 0.0001
            return (velocity_function(t + h) - velocity_function(t - h)) / (2 * h)

        return {
            'health_multiplier': health_multiplier,
            'speed_multiplier': speed_multiplier,
            'group_size': group_size,
            'pattern_cycle': pattern_cycle,
            'prime_factors': prime_factors,
            'wave_function': custom_wave,
            'velocity_function': velocity_function,
            'acceleration_function': acceleration_function
    }


    def generate_formation(self, wave_number: int, num_enemies: int) -> list:
        """Use logarithmic spirals and the golden ratio to create an enemy configuration.
            The golden ratio and prime factors are used to determine the angular spacing of each enemy,
            which is then modified using harmonic sine/cosine oscillations."""
            
        positions = []
        
        # Use prime-based pattern with golden ratio
        prime = NumberTheory.generate_prime(2, wave_number + 2)
        golden_ratio = (1 + math.sqrt(5)) / 2
        
        # Use trigonometry for positioning
        for i in range(num_enemies):
            # Calculate angle using golden ratio and prime numbers
            angle = (2 * math.pi * i * prime * golden_ratio) / num_enemies
            
            # Use logarithmic spiral for radius
            radius = min(200, 100 + (wave_number * 10))
            log_radius = radius * math.exp(0.1 * i)  # Logarithmic spiral
            
            # Calculate position using advanced trigonometry
            x = math.cos(angle) * log_radius
            y = math.sin(angle) * log_radius
            
            # Add harmonic motion
            harmonic_x = 10 * math.sin(2 * math.pi * i / num_enemies)
            harmonic_y = 10 * math.cos(2 * math.pi * i / num_enemies)
            
            positions.append((int(x + harmonic_x), int(y + harmonic_y)))
        
        return positions

    def calculate_movement_timing(self, wave_number: int) -> dict:
        """Determine the temporal limits of movement for a particular wave.
        Returns: 
            dict: Consists of methods for speed, acceleration, difficulty, and delay.
        """
        # Use GCD for synchronization with phase shifts
        base_delay = NumberTheory.gcd(wave_number, 60)
        
        # Use modulo for pattern variation with custom wave functions
        pattern_type = wave_number % 3
        
        # Use prime factors for complexity with harmonic motion
        prime_factors = NumberTheory.prime_factors(wave_number)
        complexity = len(prime_factors)
        
        # Calculate velocity using calculus concepts
        def velocity_function(t):
            return math.sin(2 * math.pi * t / base_delay) * complexity
        
        # Calculate acceleration using derivatives
        def acceleration_function(t):
            h = 0.0001
            return (velocity_function(t + h) - velocity_function(t - h)) / (2 * h)
        
        return {
            'base_delay': max(10, base_delay),
            'pattern_type': pattern_type,
            'complexity': complexity,
            'velocity_function': velocity_function,
            'acceleration_function': acceleration_function
        }

    def spawn_enemies(self, num_enemies, wave_number):
        """Spawn enemy entities with mathematically scaled health and speed."""
        enemies = []
        center_x = WIDTH // 2
        center_y = HEIGHT // 4

        # 🔍 Get difficulty scaling from number theory
        pattern = self.generate_wave_pattern(wave_number)
        health_multiplier = pattern['health_multiplier']
        speed_multiplier = pattern['speed_multiplier']

        # Determine positions 
        for i in range(num_enemies):
            # Use golden ratio for spacing
            golden_ratio = (1 + math.sqrt(5)) / 2
            angle = 2 * math.pi * i * golden_ratio

            # Calculate spawn position
            radius = 100 + wave_number * 10
            x = center_x + radius * math.cos(angle)
            y = center_y + radius * math.sin(angle)

            # Ensure enemies stay within screen bounds
            x = max(50, min(x, WIDTH - 50))
            y = max(50, min(y, HEIGHT // 2))

            # Create enemy
            enemy = Enemy(x, y, i)
            enemy.health = ENEMY_MAX_HEALTH * health_multiplier
            enemy.speed = ENEMY_BASE_SPEED * speed_multiplier  # 💡 You may need to ensure Enemy class uses this
            enemy.game = self
            enemies.append(enemy)

        return enemies

    def handle_events(self):
        """During the game, manage system and user events."""
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return False
                elif event.key == pygame.K_SPACE and not self.game_over_state and not self.game_won:
                    current_time = pygame.time.get_ticks()
                    if current_time - self.last_shot_time > self.shot_delay:
                        self.player.shoot()
                        self.last_shot_time = current_time
                elif event.key == pygame.K_r and (self.game_over_state or self.game_won):
                    self.reset_game()
        return True

    def update(self):
        """Update the game state """
        if not self.game_over_state:
            # Update game time
            self.game_time += 1
            
            # Update player
            keys = pygame.key.get_pressed()
            self.player.move(keys)
            self.player.update()
            
            # Update enemies
            for enemy in self.enemies[:]:
                # Update enemy movement
                enemy.move(self.game_time, self.player.projectiles)
                enemy.update_projectiles()
                
                # Check for collisions with player shots
                for projectile in self.player.projectiles[:]:
                    if enemy.rect.colliderect(projectile['rect']):
                        enemy.take_damage(25)  # Regular shot damage
                        self.player.projectiles.remove(projectile)
                        if enemy.health <= 0:
                            self.player.score += 100
                
                # Check for collisions with power shots
                for power_shot in self.player.power_shots[:]:
                    if enemy.rect.colliderect(power_shot.rect):
                        enemy.take_damage(50)  # Power shot damage
                        self.player.power_shots.remove(power_shot)
                        if enemy.health <= 0:
                            self.player.score += 150
                
                # Check for collisions with enemy shots 
                for projectile in enemy.projectiles[:]:
                    if self.player.rect.colliderect(projectile['rect']):
                        if self.player.take_damage(5):  # Reduced enemy projectile damage from 10 to 5
                            enemy.projectiles.remove(projectile)
                            if self.player.health <= 0:
                                self.game_over_state = True
                
                # Remove eliminated enemies
                if enemy.health <= 0:
                    if enemy in self.enemies:
                        self.enemies.remove(enemy)
            
            # Check for wave completion
            if len(self.enemies) == 0:
                self.wave_number += 1
                if self.wave_number > MAX_WAVES:
                    self.game_won = True
                else:
                    self.player.score += WAVE_COMPLETION_BONUS
                    self.enemies = self.spawn_enemies(4, self.wave_number)

    def draw(self):
        """Display every visual component of the game on the screen."""
        self.screen.fill(BLACK)
        
        # Draw stars
        for star in self.stars:
            star.draw(self.screen)
        
        if not self.game_over_state and not self.game_won:
            # Draw game objects
            self.player.draw(self.screen, self.font)
            for enemy in self.enemies:
                enemy.draw(self.screen)
            
            # Displays wave counter
            wave_text = self.font.render(f"Wave: {self.wave_number}/{MAX_WAVES}", True, WHITE)
            self.screen.blit(wave_text, (WIDTH//2 - wave_text.get_width()//2, 8))
            
            # Dispalys controls
            controls_text = self.font.render("SPACE: Shoot (Auto Power Shots) | ESC: Quit", True, WHITE)
            self.screen.blit(controls_text, (WIDTH//2 - controls_text.get_width()//2, HEIGHT - 30))
        
        elif self.game_won:
            self.draw_victory_screen()
        else:
            self.draw_game_over_screen()
        
        pygame.display.flip()

    def draw_victory_screen(self):
        """Displays the victory screen."""
        victory_text = self.font.render("Congratulations! You Won!", True, WHITE)
        final_score_text = self.font.render(f"Final Score: {self.player.score}", True, WHITE)
        high_score_text = self.font.render(f"High Score: {self.high_score}", True, WHITE)
        restart_text = self.font.render("Press R to Play Again", True, WHITE)
        
        self.screen.blit(victory_text, (WIDTH//2 - victory_text.get_width()//2, HEIGHT//2 - 80))
        self.screen.blit(final_score_text, (WIDTH//2 - final_score_text.get_width()//2, HEIGHT//2 - 20))
        self.screen.blit(high_score_text, (WIDTH//2 - high_score_text.get_width()//2, HEIGHT//2 + 20))
        self.screen.blit(restart_text, (WIDTH//2 - restart_text.get_width()//2, HEIGHT//2 + 60))

    def draw_game_over_screen(self):
        """Display the game over screen."""
        game_over_text = self.font.render("Game Over! Press R to Restart", True, WHITE)
        final_score_text = self.font.render(f"Final Score: {self.player.score}", True, WHITE)
        wave_text = self.font.render(f"Waves Completed: {self.wave_number - 1}/{MAX_WAVES}", True, WHITE)
        high_score_text = self.font.render(f"High Score: {self.high_score}", True, WHITE)
        
        self.screen.blit(game_over_text, (WIDTH//2 - game_over_text.get_width()//2, HEIGHT//2 - 80))
        self.screen.blit(final_score_text, (WIDTH//2 - final_score_text.get_width()//2, HEIGHT//2 - 20))
        self.screen.blit(wave_text, (WIDTH//2 - wave_text.get_width()//2, HEIGHT//2 + 20))
        self.screen.blit(high_score_text, (WIDTH//2 - high_score_text.get_width()//2, HEIGHT//2 + 60))

    def save_high_score(self):
        """Save high score using number theory encryption."""
        encrypted_score = self.score_encryption.encrypt(self.high_score)
        # Save encrypted_score to file or database
        return encrypted_score

    def load_high_score(self, encrypted_score):
        """Load high score using number theory decryption."""
        self.high_score = self.score_encryption.decrypt(encrypted_score)
        return self.high_score

    def run(self):
        """Main game loop."""
        running = True
        while running:
            # Handle events
            running = self.handle_events()
            
            # Update game state
            self.update()
            
            # Draw everything
            self.draw()
            
            # Cap the frame rate
            self.clock.tick(FPS)
        
        pygame.quit()

class AdvancedTrigonometry:
    @staticmethod
    def complex_wave_pattern(t, amplitude, frequency, phase, harmonics=3):
        """provides complex trigonometric patterns that are utilized in the game's
            wave and dynamic enemy movement animations."""
        result = 0
        for n in range(1, harmonics + 1):
            # Add multiple harmonics with decreasing amplitude
            result += (amplitude / n) * math.sin(2 * math.pi * n * frequency * t + phase)
        return result

    @staticmethod
    def spiral_movement(t, center_x, center_y, radius, angular_speed, expansion_rate):
        """Create spiral movement pattern for enemys.""" 
        # Calculate angle and radius based on time and expansion rate
        angle = t * angular_speed
        current_radius = radius * (1 + expansion_rate * t)
        x = center_x + current_radius * math.cos(angle)
        y = center_y + current_radius * math.sin(angle)
        return x, y

def main():
    """Main function to run the game."""
    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("Trigon Riad")
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 36)
    
    # Create background
    background = pygame.Surface((WIDTH, HEIGHT))
    background.fill(BLACK)
    
    # Initialize game
    game = Game()
    
    # Main game loop
    running = True
    while running:
        # Handle events
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    running = False
                elif event.key == pygame.K_SPACE and not game.game_over_state and not game.game_won:
                    current_time = pygame.time.get_ticks()
                    if current_time - game.last_shot_time > game.shot_delay:
                        game.player.shoot()
                        game.last_shot_time = current_time
                elif event.key == pygame.K_r and (game.game_over_state or game.game_won):
                    game.reset_game()
        
        # Update game state
        game.update()
        
        # Draw background
        screen.fill(BLACK)
        
        # Draw stars
        for star in game.stars:
            star.draw(screen)
        
        if not game.game_over_state and not game.game_won:
            # Displays game objects
            game.player.draw(screen, font)
            for enemy in game.enemies:
                enemy.draw(screen)
            
            # Displays wave counter
            wave_text = font.render(f"Wave: {game.wave_number}/{MAX_WAVES}", True, WHITE)
            screen.blit(wave_text, (WIDTH//2 - wave_text.get_width()//2, 8))
            
            # Displays controls
            controls_text = font.render("SPACE: Shoot (Auto Power Shots) | ESC: Quit", True, WHITE)
            screen.blit(controls_text, (WIDTH//2 - controls_text.get_width()//2, HEIGHT - 30))
        
        elif game.game_won:
            # Displays victory screen
            victory_text = font.render("Congratulations! You Won!", True, WHITE)
            final_score_text = font.render(f"Final Score: {game.player.score}", True, WHITE)
            high_score_text = font.render(f"High Score: {game.high_score}", True, WHITE)
            restart_text = font.render("Press R to Play Again", True, WHITE)
            
            screen.blit(victory_text, (WIDTH//2 - victory_text.get_width()//2, HEIGHT//2 - 80))
            screen.blit(final_score_text, (WIDTH//2 - final_score_text.get_width()//2, HEIGHT//2 - 20))
            screen.blit(high_score_text, (WIDTH//2 - high_score_text.get_width()//2, HEIGHT//2 + 20))
            screen.blit(restart_text, (WIDTH//2 - restart_text.get_width()//2, HEIGHT//2 + 60))
        else:
            # Displays game over screen
            game_over_text = font.render("Game Over! Press R to Restart", True, WHITE)
            final_score_text = font.render(f"Final Score: {game.player.score}", True, WHITE)
            wave_text = font.render(f"Waves Completed: {game.wave_number - 1}/{MAX_WAVES}", True, WHITE)
            high_score_text = font.render(f"High Score: {game.high_score}", True, WHITE)
            
            screen.blit(game_over_text, (WIDTH//2 - game_over_text.get_width()//2, HEIGHT//2 - 80))
            screen.blit(final_score_text, (WIDTH//2 - final_score_text.get_width()//2, HEIGHT//2 - 20))
            screen.blit(wave_text, (WIDTH//2 - wave_text.get_width()//2, HEIGHT//2 + 20))
            screen.blit(high_score_text, (WIDTH//2 - high_score_text.get_width()//2, HEIGHT//2 + 60))
        
        pygame.display.flip()
        clock.tick(FPS)
    
    pygame.quit()

if __name__ == "__main__":
    main() 