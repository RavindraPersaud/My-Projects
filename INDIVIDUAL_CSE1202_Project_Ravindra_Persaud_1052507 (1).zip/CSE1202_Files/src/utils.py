"""
Utility functions for game mechanics
"""

import math
import pygame
from config import WHITE, RED, GREEN
import numpy as np

def draw_health_bar(screen, x, y, health, max_health, color=GREEN):
    """Shows a health bar accoriding to the player's health."""
    ratio = health / max_health
    pygame.draw.rect(screen, RED, (x, y, 100, 10))
    pygame.draw.rect(screen, color, (x, y, 100 * ratio, 10))

def rotate_vector(vector, angle_degrees):
    """
   Changes the 2D vector by a specified angle applying trigonometric concepts (the rotation matrices).
        vector: A tuple (x, y)
        angle_degrees: The angle rotation in degrees
        Returns:
        The rotated vector (x', y') 
        
        x' = x * cos(θ) - y * sin(θ)
        y' = x * sin(θ) + y * cos(θ)
    """
    angle_radians = math.radians(angle_degrees)
    x, y = vector
    new_x = x * math.cos(angle_radians) - y * math.sin(angle_radians)
    new_y = x * math.sin(angle_radians) + y * math.cos(angle_radians)
    return (new_x, new_y)

# Vector operations
def vector_add(v1, v2):
    return (v1[0] + v2[0], v1[1] + v2[1])

def vector_sub(v1, v2):
    return (v1[0] - v2[0], v1[1] - v2[1])

def vector_mul(v, scalar):
    #Increases a vector v by a scalar value (utilized for change in speed or acceleration).
    return (v[0] * scalar, v[1] * scalar)

def vector_length(v):
    return math.sqrt(v[0]**2 + v[1]**2)

def vector_normalize(v):
    length = vector_length(v)
    if length == 0:
        return (0, 0)
    return (v[0] / length, v[1] / length)

# Trigonometric utilities
def angle_to_vector(angle):
    return (math.cos(math.radians(angle)), -math.sin(math.radians(angle)))

def vector_to_angle(v):
    return math.degrees(math.atan2(-v[1], v[0]))

# determines the acceleration vector required to change the current velocity to get a collision .
def calculate_acceleration(current_vel, target_vel, max_accel):
    diff = vector_sub(target_vel, current_vel)
    length = vector_length(diff)
    if length > max_accel:
        diff = vector_mul(vector_normalize(diff), max_accel)
    return diff

"""Determines and provides a list of all prime factors of n.
Utilized in calculate_wave_difficulty() for determining scaling."""
def calculate_wave_difficulty(wave_number):
    
    factors = prime_factors(wave_number)
    health_multiplier = 1 + sum(factors) * 0.1
    speed_multiplier = 1 + len(factors) * 0.05
    return health_multiplier, speed_multiplier

def prime_factors(n):
    factors = []
    while n % 2 == 0:
        factors.append(2)
        n = n // 2
    i = 3
    while i * i <= n:
        while n % i == 0:
            factors.append(i)
            n = n // i
        i += 2
    if n > 2:
        factors.append(n)
    return factors

""" aims the shots in the path of a moving target based on its predicted location.
    Returns:
       place to aim at for interception (x, y)
"""

def predict_target_position(target_pos, target_vel, projectile_speed):
    # Solve system of equations for interception point
    dx = target_pos[0] - PLAYER_POS[0]
    dy = target_pos[1] - PLAYER_POS[1]
    
    a = target_vel[0]**2 + target_vel[1]**2 - projectile_speed**2
    b = 2 * (dx * target_vel[0] + dy * target_vel[1])
    c = dx**2 + dy**2
    
    discriminant = b**2 - 4*a*c
    if discriminant < 0:
        return target_pos  # No interception possible
        
    t = (-b - math.sqrt(discriminant)) / (2*a)
    if t < 0:
        return target_pos  # Negative time, aim directly
        
    return (target_pos[0] + target_vel[0]*t,
            target_pos[1] + target_vel[1]*t) 