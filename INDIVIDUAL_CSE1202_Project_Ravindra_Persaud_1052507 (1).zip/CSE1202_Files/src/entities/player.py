"""
Implementation of player objects.

The player class, which is in charge of movement, shooting, health management,
invulnerability logic, and rendering, is defined in this module.
"""

import pygame
from config import (
    WIDTH, HEIGHT, PLAYER_MAX_HEALTH, WHITE,
    PLAYER_SPRITE, LASER_SOUND, POWER_SHOT_SOUND, IMPACT_SOUND
)
from utils import draw_health_bar
from entities.power_shot import PowerShot


# Constants for player movement and shooting
class Player:
    """
    This class representing the user's spaceship.
    
    Instance Variables:
- x, y: Position of the player
- speed: speed of the player
- sprite, rect: picture and hitbox
- projectiles, power_shots: projectiles fired 
- health, score: Game stats
- last_power_shot_time: Power shot timer
- invulnerable: Damage cooldown flag
 
    """
    def __init__(self):
        self.x = WIDTH // 2
        self.y = HEIGHT - 100
        self.speed = 5
        self.sprite = pygame.image.load(PLAYER_SPRITE)
        # Scale down the player sprite to 50% of its original size
        self.sprite = pygame.transform.scale(self.sprite, 
            (self.sprite.get_width() // 2, self.sprite.get_height() // 2))
        self.rect = self.sprite.get_rect()
        self.rect.center = (self.x, self.y)
        self.projectiles = []
        self.power_shots = []
        self.health = PLAYER_MAX_HEALTH
        self.last_power_shot_time = 0
        self.power_shot_delay = 2000
        self.score = 0
        self.invulnerable = False
        self.invulnerable_timer = 0
        self.invulnerable_duration = 60  # 1 second at 60 FPS

    def move(self, keys):
        """Manage keyboard input for player movement and shooting."""
        # Horizontal movement
        if keys[pygame.K_LEFT] or keys[pygame.K_a]:
            self.x = max(0, self.x - self.speed)
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
            self.x = min(WIDTH - self.rect.width, self.x + self.speed)
        
        # Vertical movement
        if keys[pygame.K_UP] or keys[pygame.K_w]:
            self.y = max(0, self.y - self.speed)
        if keys[pygame.K_DOWN] or keys[pygame.K_s]:
            self.y = min(HEIGHT - self.rect.height, self.y + self.speed)
        
        # Update rect position
        self.rect.x = int(self.x)
        self.rect.y = int(self.y)
        
        # Handle shooting
        if keys[pygame.K_SPACE]:
            current_time = pygame.time.get_ticks()
            if current_time - self.last_power_shot_time > self.power_shot_delay:
                self.shoot()
                self.last_power_shot_time = current_time

    def shoot(self):
        """Fires in two ways a power shot (if available) or a standard shot.
            Cooldown is used for power shots."""
        current_time = pygame.time.get_ticks()
        if current_time - self.last_power_shot_time > self.power_shot_delay:
            self.power_shots.append(PowerShot(self.x, self.y))
            self.last_power_shot_time = current_time
            pygame.mixer.Sound(POWER_SHOT_SOUND).play()
        else:
            self.projectiles.append({
                'x': self.x,
                'y': self.y,
                'rect': pygame.Rect(self.x - 2, self.y - 10, 4, 20),
                'angle': 90  # Angle for upward movement
            })
            pygame.mixer.Sound(LASER_SOUND).play()

    def update(self):
        """Update player's projectiles and power shots."""
        # Update regular projectiles
        for projectile in self.projectiles[:]:
            projectile['y'] -= 10
            projectile['rect'].y = projectile['y']
            if projectile['y'] < -20:  # Remove if off screen
                self.projectiles.remove(projectile)

        # Update power shots
        for power_shot in self.power_shots[:]:
            power_shot.update()
            if power_shot.y < -30:  # Remove if off screen
                self.power_shots.remove(power_shot)

        # Update invulnerability
        if self.invulnerable:
            self.invulnerable_timer -= 1
            if self.invulnerable_timer <= 0:
                self.invulnerable = False

    def take_damage(self, amount):
        """Reduces the player's health if not currently invulnerable."""
        if not self.invulnerable:
            self.health = max(0, self.health - amount)
            self.invulnerable = True
            self.invulnerable_timer = self.invulnerable_duration
            pygame.mixer.Sound(IMPACT_SOUND).play()
            return True
        return False

    def draw(self, screen, font):
        """Renders the player with visual effects (player, projectiles, and HUD - health & score)."""
        # Displays blinking effect when invulnerable
        if not self.invulnerable or (self.invulnerable and self.invulnerable_timer % 6 < 3):
            screen.blit(self.sprite, self.rect)

        # Draw projectiles
        for projectile in self.projectiles:
            pygame.draw.rect(screen, WHITE, projectile['rect'])
        
        # Draw power shots with effects
        for power_shot in self.power_shots:
            power_shot.draw(screen)

        # Draw health bar and score
        draw_health_bar(screen, 10, 10, self.health, PLAYER_MAX_HEALTH)
        health_text = font.render(f"Health: {int(self.health)}", True, WHITE)
        score_text = font.render(f"Score: {self.score}", True, WHITE)
        screen.blit(health_text, (120, 8))
        screen.blit(score_text, (WIDTH - 200, 8)) 