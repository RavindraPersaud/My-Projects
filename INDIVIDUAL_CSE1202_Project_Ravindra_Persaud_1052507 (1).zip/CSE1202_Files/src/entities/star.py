"""
Stars for background effects.
"""

import pygame
import random
import math
from config import WIDTH, HEIGHT, WHITE

class Star:
    """
    Represents a star in the starfield background.
    
    Attributes:
        id (int): Unique identifier for the star
        x (int): X-coordinate of the star
        y (int): Y-coordinate of the star
        speed (float): Movement speed of the star
        size (int): Size of the star
        angle (float): Current angle of movement
        radius (float): Radius of circular motion
        angular_speed (float): Speed of angle change
    """
    def __init__(self):
        self.id = random.randint(0, 1000)  # Generate random ID
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(0, HEIGHT)
        self.speed = random.uniform(0.5, 2.0)
        self.size = random.randint(1, 3)
        self.color = (random.randint(200, 255), random.randint(200, 255), random.randint(200, 255))
        self.angle = random.uniform(0, 2 * math.pi)
        self.radius = random.uniform(50, 150)
        self.angular_speed = random.uniform(0.01, 0.05)

    def move(self, pattern_mod):
        """Changing the star's position based on a pattern."""
        # Using trigonometry for circular motion of the star
        self.angle += self.angular_speed
        self.x += math.cos(self.angle) * self.speed
        self.y += math.sin(self.angle) * self.speed
        
        # Uses mod to change the behavior based on wave or game phase
        if pattern_mod % 2 == 0:
            self.radius += math.sin(self.angle) * 0.1
        else:
            self.radius -= math.cos(self.angle) * 0.1
            
        # A slight shift in pace over time to allow for natural flow
        self.speed += math.sin(self.angle) * 0.01
        
        # Wrap around screen edges
        if self.x < 0:
            self.x = WIDTH
        elif self.x > WIDTH:
            self.x = 0
        if self.y < 0:
            self.y = HEIGHT
        elif self.y > HEIGHT:
            self.y = 0

    def draw(self, screen):
        """Displays the star onto the designated region of the screen."""
        pygame.draw.circle(screen, self.color, (int(self.x), int(self.y)), self.size) 