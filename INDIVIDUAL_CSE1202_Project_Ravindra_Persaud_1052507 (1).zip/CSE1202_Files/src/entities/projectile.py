import math

def predict_target_position(target_pos, target_vel, projectile_speed):
    """
    Applied linear algebra and calculus for predicting the future location of a moving object.
    target_pos (tuple): The target's present position (x, y).
    target_vel (tuple): The target's present speed (vx, vy).
    projectile_speed (float): The projectile's velocity.
    tuple: predicted future position (x, y) that the missile is expected to shoot towards.
    """
    # Determine the relative location and velocity between target and shooter.
    dx = target_pos[0] - self.x
    dy = target_pos[1] - self.y
    
    # # Set up a, b, c for the quadratic equation to find intercept time
    a = target_vel[0]**2 + target_vel[1]**2 - projectile_speed**2
    b = 2 * (dx * target_vel[0] + dy * target_vel[1])
    c = dx**2 + dy**2
    
    # Solve quadratic equation for time
    discriminant = b**2 - 4*a*c
    if discriminant < 0:
        return target_pos  # No actual answer, just shoot straight.
        
    t = (-b - math.sqrt(discriminant)) / (2*a)
    if t < 0:
        return target_pos  # Ignore negative time.
        
    # Calculate predicted position
    predicted_x = target_pos[0] + target_vel[0]*t
    predicted_y = target_pos[1] + target_vel[1]*t
    
    return (predicted_x, predicted_y)

def update(self):
    """Modify missile to target and advance towards the target."""
    # Determine the target's direction.
    if self.target:
        # Obtain target information 
        target_pos = (self.target.x, self.target.y)
        target_vel = (self.target.velocity[0], self.target.velocity[1])
        
        # Determine the place of interception.
        predicted_pos = predict_target_position(target_pos, target_vel, self.speed)
        
        # Determine the path to the anticipated location.
        dx = predicted_pos[0] - self.x
        dy = predicted_pos[1] - self.y
        distance = math.sqrt(dx**2 + dy**2)
        
        if distance > 0:
            # Normalize direction
            self.velocity[0] = (dx / distance) * self.speed
            self.velocity[1] = (dy / distance) * self.speed
    
    # Update position
    self.x += self.velocity[0]
    self.y += self.velocity[1]
    
    # Update hitbox
    self.rect.center = (int(self.x), int(self.y))
    
    # move if off screen
    if (self.x < -50 or self.x > WIDTH + 50 or 
        self.y < -50 or self.y > HEIGHT + 50):
        self.game.projectiles.remove(self) 