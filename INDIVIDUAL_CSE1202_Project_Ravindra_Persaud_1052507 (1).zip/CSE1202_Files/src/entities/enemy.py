"""Implementation of Enemy objects."""

import pygame
import random
import math
import numpy as np
from config import (
    WIDTH, HEIGHT, ENEMY_MAX_HEALTH, DRONE_SPRITE,
    PROJECTILE_SPRITE, EXPLOSION_SOUND, IMPACT_SOUND,
    WHITE, HIT_EFFECT, EXPLOSION_SPRITE, SMALL_EXPLOSION_SPRITE
)
from utils import draw_health_bar

class Enemy:
    """
    Handles movement, shooting, damage, and animations. Each enemy uses a stochastic movement pattern 
    (sine, circular, or zigzag) derived from mathematical functions.
    
Instance Variables:
- x, y: Position on screen
- speed: Movement speed
- health: Current health
- sprite, rect: Visual and collision representation
- projectiles: Enemy bullets
- movement_pattern: Movement behavior type
- velocity: Frame-to-frame position change (used for prediction)
- explosion_frame: Tracks explosion animation state
    """
    def __init__(self, x, y, index):
        self.x = x
        self.y = y
        self.speed = random.randint(2, 4)
        self.health = ENEMY_MAX_HEALTH
        self.sprite = pygame.image.load(DRONE_SPRITE)
        self.rect = self.sprite.get_rect(center=(self.x, self.y))
        self.projectiles = []
        self.movement_pattern = random.choice(['sine', 'circle', 'zigzag'])
        self.initial_x = x
        self.time_offset = random.uniform(0, 2 * math.pi)
        self.last_shot_time = 0
        self.shoot_delay = random.randint(1000, 2000)
        self.hit_effect_active = False
        self.hit_effect_frame = 0
        self.hit_effect_duration = 10
        self.health_idx = index
        self.velocity = np.array([0.0, 0.0], dtype=np.float32)
        self.last_x = x
        self.last_y = y
        self.exploding = False
        self.explosion_frame = 0
        self.explosion_duration = 20  # decreases for quicker explosion
        self.time = 0
        self.pattern_type = self.movement_pattern
        self.start_x = x
        self.start_y = y

    def evade(self, projectiles):
        """
        Attempts to maneuver in order to avoid approaching missiles.
        """
        margin = 40  # Match the margin from move method
        for projectile in projectiles:
            dx = projectile['x'] - self.x
            dy = projectile['y'] - self.y
            distance = math.sqrt(dx * dx + dy * dy)
            
            if distance < 100:  # determine if the projectile is close
                # Move perpendicular to the projectile's path
                angle = math.atan2(dy, dx)
                evade_angle = angle + math.pi/2
                new_x = self.x + math.cos(evade_angle) * self.speed
                new_y = self.y + math.sin(evade_angle) * self.speed
                
                # Enforce strict screen boundaries during evasion
                self.x = max(margin, min(new_x, WIDTH - self.rect.width - margin))
                self.y = max(margin, min(new_y, HEIGHT//4))  # Keep in top quarter

    def shoot(self, angle):
        """Shoots a projectile at a given angle"""
        current_time = pygame.time.get_ticks()
        if current_time - self.last_shot_time > self.shoot_delay:
            # deteremines projectile speed based on an angle
            angle_rad = math.radians(angle)
            velocity_x = math.cos(angle_rad) * 7  # Fixed projectile speed
            velocity_y = math.sin(angle_rad) * 7  # Fixed projectile speed
            
            # Create projectile
            projectile = {
                'x': self.x + self.rect.width//2,
                'y': self.y + self.rect.height,
                'velocity_x': velocity_x,
                'velocity_y': velocity_y,
                'rect': pygame.Rect(self.x + self.rect.width//2, self.y + self.rect.height, 8, 8),
                'angle': angle  # Store the angle for rotation
            }
            
            self.projectiles.append(projectile)
            self.last_shot_time = current_time

    def update_projectiles(self):
        """Update all enemy projectiles and removes any that are off screen."""
        for p in self.projectiles[:]:
            # Update position using velocity
            p['x'] += p['velocity_x']
            p['y'] += p['velocity_y']
            p['rect'].x = int(p['x'])
            p['rect'].y = int(p['y'])
            
            # Remove if off screen
            if (p['y'] > HEIGHT + 50 or p['y'] < -50 or 
                p['x'] < -50 or p['x'] > WIDTH + 50):
                self.projectiles.remove(p)

    def move(self, game_time, player_projectiles):
        """Update enemy position based on movement pattern"""
        
        self.last_x = self.x
        self.last_y = self.y
        
        margin = 40  # Increased margin to keep enemies well within screen
        
        if self.movement_pattern == 'sine':
            # Limit sine wave movement
            max_amplitude = (WIDTH - 2 * margin) // 4  # Reduced amplitude to 1/4 of usable width
            self.x = self.initial_x + math.sin(game_time * 0.05 + self.time_offset) * max_amplitude
            self.y += self.speed * 0.5  # Slower downward movement
        elif self.movement_pattern == 'circle':
            angle = game_time * 0.05 + self.time_offset
            radius = 30  # Reduced radius for tighter movement
            self.x = self.initial_x + math.cos(angle) * radius
            self.y += self.speed * 0.5  # Slower downward movement
        elif self.movement_pattern == 'zigzag':
            max_zigzag = (WIDTH - 2 * margin) // 4  # Reduced zigzag width
            self.x = self.initial_x + math.sin(game_time * 0.1 + self.time_offset) * max_zigzag
            self.y += self.speed * 0.5  # Slower downward movement
        
        # uses strict screen boundaries
        self.x = max(margin, min(self.x, WIDTH - margin))
        self.y = max(margin, min(self.y, HEIGHT//4))  # Keep in top quarter
        
        # determines velocity for predictive targeting
        self.velocity[0] = self.x - self.last_x
        self.velocity[1] = self.y - self.last_y
        
        # Update rect (hitbox) for collision detection
        self.rect.center = (int(self.x), int(self.y))
        
        # Update time for pattern calculations
        self.time += 1
        
        # Enhanced shooting mechanism
        current_time = pygame.time.get_ticks()
        if current_time - self.last_shot_time > self.shoot_delay:
            if hasattr(self, 'game') and self.game.player:
                dx = self.game.player.x - self.x
                dy = self.game.player.y - self.y
                angle = math.degrees(math.atan2(dy, dx))  # Removed negative sign for correct angle
                
                # Add some spread to shots based on wave number
                spread = 5  # Reduced spread for more accurate shots
                final_angle = angle + random.uniform(-spread, spread)
                self.shoot(final_angle)

    def take_damage(self, amount):
        """Reduces health by a specified amount and trigger explosion effects if neeeded."""
        old_health = self.health
        self.health = max(0, self.health - amount)
        
        # Show hit effect
        self.hit_effect_active = True
        self.hit_effect_frame = 0
        
        # Start explosion if health reaches 0
        if old_health > 0 and self.health <= 0:
            self.exploding = True
            self.explosion_frame = 0
            pygame.mixer.Sound(EXPLOSION_SOUND).play()
        else:
            pygame.mixer.Sound(IMPACT_SOUND).play()
        
        return True

    def draw(self, screen):
        """Renders the enemy with all visual effects."""
        if self.exploding:
            # Draw main explosion
            explosion_size = (120, 120)
            scaled_explosion = pygame.transform.scale(
                pygame.image.load(EXPLOSION_SPRITE), explosion_size)
            
            # Calculate center position for explosion
            explosion_x = self.x + self.rect.width//2 - explosion_size[0]//2
            explosion_y = self.y + self.rect.height//2 - explosion_size[1]//2
            
            # Draw growing explosion
            scale_factor = min(1.0, self.explosion_frame / 10)
            current_size = (int(explosion_size[0] * scale_factor), 
                          int(explosion_size[1] * scale_factor))
            current_explosion = pygame.transform.scale(scaled_explosion, current_size)
            
            # Add smaller explosions around main explosion
            if self.explosion_frame > 5:
                small_size = (60, 60)
                angles = [0, 72, 144, 216, 288]  # Spread small explosions in a circle
                radius = 40
                for angle in angles:
                    rad = math.radians(angle)
                    small_x = explosion_x + radius * math.cos(rad)
                    small_y = explosion_y + radius * math.sin(rad)
                    small_explosion = pygame.transform.scale(
                        pygame.image.load(SMALL_EXPLOSION_SPRITE), small_size)
                    screen.blit(small_explosion, (small_x, small_y))
            
            screen.blit(current_explosion, (explosion_x, explosion_y))
            self.explosion_frame += 1
        
        else:
            # Draw the enemy
            screen.blit(self.sprite, self.rect)
            
            # Draw projectiles
            projectile_img = pygame.image.load(PROJECTILE_SPRITE)
            for p in self.projectiles:
                screen.blit(projectile_img, (p['x'], p['y']))
            
            # Draw health bar
            draw_health_bar(screen, self.x, self.y - 20, self.health, ENEMY_MAX_HEALTH)
            health_text = pygame.font.Font(None, 36).render(f"{int(self.health)}", True, WHITE)
            screen.blit(health_text, (self.x, self.y - 40))
            
            # Draw hit effect
            if self.hit_effect_active:
                hit_size = (40, 40)
                hit_effect_scaled = pygame.transform.scale(
                    pygame.image.load(HIT_EFFECT), hit_size)
                hit_x = self.x + self.rect.width//2 - hit_size[0]//2
                hit_y = self.y + self.rect.height//2 - hit_size[1]//2
                screen.blit(hit_effect_scaled, (hit_x, hit_y))
                self.hit_effect_frame += 1
                if self.hit_effect_frame >= self.hit_effect_duration:
                    self.hit_effect_active = False

    def is_explosion_finished(self):
        """Check if explosion animation is complete."""
        return self.exploding and self.explosion_frame >= self.explosion_duration 