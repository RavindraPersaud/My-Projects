"""PowerShot for unique projectiles.

This class describes a special high-damage shot with a customized size, and movement."""

import pygame
from config import YELLOW, POWER_SHOT_EFFECT

class PowerShot:
    """
   Represents a powerful rocket that the player can fire.
    
    Class Instances:
        x (int): gets the X-coordinate
        y (int): gets the Y-coordinate
        speed (int): verical speed of projectile 
        rect (Rect): Collision rectangle
    """
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.speed = 12  # Increases projectile (powershot) speed
        self.rect = pygame.Rect(x - 6, y - 20, 12, 40)  # Larger collision box
        self.effect_frame = 0

    def get_damage(self, enemy_health):
        """determines damage as exactly half of enemy's current health."""
        return max(50, enemy_health * 0.5)  # The damage is either 50, or half of current health which ever is greater 

    def update(self):
        """Moves power shot position and effect."""
        self.y -= self.speed  # Move upward
        self.rect.y = self.y  # sync collision box
        self.effect_frame = (self.effect_frame + 1) % 8

    def draw(self, screen):
        """Displays power shot with trailing effect."""
        # dispplays main projectile (bigger than regular shots-power shot)
        pygame.draw.rect(screen, YELLOW, pygame.Rect(self.x - 6, self.y - 20, 12, 40))
        
        # displays trailing effect
        effect_size = (60, 60)  # Even bigger effect
        effect = pygame.transform.scale(pygame.image.load(POWER_SHOT_EFFECT), effect_size)
        
        # Create trailing effect positions (more trail positions)
        trail_positions = [(self.x - 30, self.y + i * 20) for i in range(4)]
        
        # Draw effects with fading transparency
        for i, pos in enumerate(trail_positions):
            alpha = 255 - (i * 50)  # Slower fade
            effect.set_alpha(alpha)
            screen.blit(effect, pos) 