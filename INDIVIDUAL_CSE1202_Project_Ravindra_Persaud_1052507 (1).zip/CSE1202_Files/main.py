# Primary access point for the game.
import os
import sys
import pygame
 
# Include the source(src) directory into Python's system path for imports.
sys.path.append(os.path.join(os.path.dirname(__file__), 'src'))

from game import Game

def main():
    # Initialize Pygame
    pygame.init()
    pygame.mixer.init()
    
    try:
        # Start and run game
        game = Game()
        game.run()
    except Exception as e:
        print(f"Error: {e}")
    finally:
        # End Pygame
        pygame.quit()

if __name__ == "__main__":
    main()
# This is the main entry point for the game. It initializes Pygame, sets up the game loop, and handles cleanup. 