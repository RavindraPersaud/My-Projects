#ifndef MENU_H
#define MENU_H


void delete_menu();

void end_of_menu();

void main_menu();

void search_menu();

int user_choice();


#endif
