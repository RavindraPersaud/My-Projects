#ifndef SEARCH_H
#define SEARCH_H


void search_by_id();

void search_by_phrase();

void search_by_title();


#endif
