"""
PredictiveAnalyticsGUI: A graphical user interface for predictive analytics.

This module implements a Tkinter-based GUI for:
- Uploading and visualizing data
- Making predictions using a linear regression model
- Displaying real-time data collection
- Showing prediction results and error metrics

Example usage:
    >>> root = tk.Tk()
    >>> app = PredictiveAnalyticsGUI(root)
    >>> app.run()
"""

import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from matplotlib.figure import Figure
import pandas as pd
import numpy as np
import queue
import time
import threading
from models.prediction_model import SimplePredictionModel
from utils.data_collector import DataCollector

class PredictiveAnalyticsGUI:
    """
    A GUI application for predictive analytics.
    
    This class provides a graphical interface for:
    - Uploading data files (CSV/Excel)
    - Starting/stopping real-time data collection
    - Making predictions using a linear regression model
    - Visualizing data and predictions
    - Displaying prediction metrics
    
    Attributes:
        root (tk.Tk): The main Tkinter window
        data_queue (queue.Queue): Queue for data collection
        is_collecting (bool): Flag for data collection status
        current_data (pd.DataFrame): Currently loaded/collected data
        prediction_model (SimplePredictionModel): Model for making predictions
        data_collector (DataCollector): Utility for generating test data
    """
    
    def __init__(self, root: tk.Tk):
        """
        Initialize the GUI with the main window.
        
        Args:
            root (tk.Tk): The main Tkinter window
        """
        self.root = root
        self.root.title("Predictive Analytics Dashboard")
        self.root.geometry("1200x800")
        
        # Initialize variables
        self.data_queue = queue.Queue()
        self.is_collecting = False
        self.current_data = None
        self.prediction_model = SimplePredictionModel()
        self.data_collector = DataCollector()
        
        # Setup GUI
        self.setup_gui()
        
    def setup_gui(self):
        """
        Setup all GUI components.
        
        Creates and arranges:
        - Control frame with buttons
        - Visualization frame with matplotlib plot
        - Analysis frame with prediction metrics
        """
        # Create frames
        self.input_frame = ttk.LabelFrame(self.root, text="Controls", padding="5")
        self.input_frame.pack(fill=tk.X, padx=5, pady=5)
        
        self.visualization_frame = ttk.LabelFrame(self.root, text="Visualization", padding="5")
        self.visualization_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.analysis_frame = ttk.LabelFrame(self.root, text="Analysis", padding="5")
        self.analysis_frame.pack(fill=tk.X, padx=5, pady=5)
        
        # Create buttons
        self.upload_button = ttk.Button(self.input_frame, text="Upload CSV/Excel",
                                      command=self.upload_file)
        self.upload_button.pack(side=tk.LEFT, padx=5)
        
        self.start_button = ttk.Button(self.input_frame, text="Start Collection",
                                     command=self.toggle_data_collection)
        self.start_button.pack(side=tk.LEFT, padx=5)
        
        self.predict_button = ttk.Button(self.input_frame, text="Make Prediction",
                                       command=self.make_prediction)
        self.predict_button.pack(side=tk.LEFT, padx=5)
        
        # Create labels
        self.prediction_label = ttk.Label(self.analysis_frame, text="Prediction: ")
        self.prediction_label.pack(side=tk.LEFT, padx=5)
        
        self.error_label = ttk.Label(self.analysis_frame, text="Error: ")
        self.error_label.pack(side=tk.LEFT, padx=5)
        
        # Setup plot
        self.fig = Figure(figsize=(10, 6))
        self.ax = self.fig.add_subplot(111)
        self.canvas = FigureCanvasTkAgg(self.fig, master=self.visualization_frame)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

    def upload_file(self):
        """
        Handle file upload.
        
        Supports:
        - CSV files (*.csv)
        - Excel files (*.xlsx, *.xls)
        
        Automatically detects and handles timestamp columns.
        """
        filetypes = [("CSV files", "*.csv"), ("Excel files", "*.xlsx;*.xls")]
        filename = filedialog.askopenfilename(filetypes=filetypes)
        
        if not filename:
            return
            
        try:
            self.current_data = pd.read_csv(filename) if filename.endswith('.csv') else pd.read_excel(filename)
            
            if 'timestamp' in self.current_data.columns:
                self.current_data['timestamp'] = pd.to_datetime(self.current_data['timestamp'])
                self.current_data.set_index('timestamp', inplace=True)
                
            self.update_plot()
            messagebox.showinfo("Success", "File loaded successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Error loading file: {str(e)}")

    def toggle_data_collection(self):
        """
        Toggle data collection on/off.
        
        Starts or stops the data collection thread and updates the button text.
        """
        if not self.is_collecting:
            self.start_collection()
        else:
            self.stop_collection()

    def start_collection(self):
        """
        Start data collection in a separate thread.
        
        Creates a daemon thread for continuous data collection.
        """
        self.is_collecting = True
        self.start_button.config(text="Stop Collection")
        threading.Thread(target=self.collect_data, daemon=True).start()

    def stop_collection(self):
        """
        Stop data collection.
        
        Sets the collection flag to False and updates the button text.
        """
        self.is_collecting = False
        self.start_button.config(text="Start Collection")

    def collect_data(self):
        """
        Collect data using the data collector.
        
        Continuously generates new data points and updates the visualization.
        Runs in a separate thread.
        """
        while self.is_collecting:
            try:
                new_data = self.data_collector.generate_data(num_points=10)
                self.current_data = new_data if self.current_data is None else pd.concat([self.current_data, new_data])
                self.update_plot()
                time.sleep(1)
            except Exception as e:
                messagebox.showerror("Error", f"Error collecting data: {str(e)}")
                self.stop_collection()

    def make_prediction(self):
        """
        Make predictions using the trained model.
        
        Steps:
        1. Validate available data
        2. Train the model
        3. Generate future timestamps
        4. Make predictions
        5. Update the display
        """
        if self.current_data is None:
            messagebox.showwarning("Warning", "No data available for prediction")
            return
            
        if len(self.current_data) < 2:
            messagebox.showwarning("Warning", "Not enough data points for prediction")
            return
            
        if not self.prediction_model.train(self.current_data):
            messagebox.showerror("Error", "Failed to train the prediction model")
            return
            
        future_timestamps = pd.date_range(start=self.current_data.index[-1], periods=10, freq='h')
        predictions = self.prediction_model.predict(future_timestamps)
        
        if predictions is None:
            messagebox.showerror("Error", "Failed to generate predictions")
            return
            
        error = self.prediction_model.calculate_error()
        self.update_predictions(pd.Series(predictions, index=future_timestamps), error)
        self.update_plot_with_predictions(future_timestamps, predictions)

    def update_plot(self):
        """
        Update the visualization with new data.
        
        Clears and redraws the plot with current data.
        Shows actual data points in blue with circles.
        """
        if self.current_data is None:
            return
            
        self.ax.clear()
        self.current_data.plot(ax=self.ax, label='Actual Data', color='blue', marker='o')
        self.ax.set_title("Real-time Data")
        self.ax.set_xlabel("Time")
        self.ax.set_ylabel("Value")
        self.ax.legend()
        self.ax.tick_params(axis='x', labelsize=8)
        self.fig.tight_layout()
        self.canvas.draw()

    def update_plot_with_predictions(self, future_timestamps, predictions):
        """
        Update the plot to include predictions.
        
        Shows:
        - Actual data in blue with circles
        - Predictions in red with dashed lines and squares
        
        Args:
            future_timestamps (pd.DatetimeIndex): Timestamps for predictions
            predictions (np.ndarray): Predicted values
        """
        if self.current_data is None:
            return
            
        self.ax.clear()
        self.current_data.plot(ax=self.ax, label='Actual Data', color='blue', marker='o')
        self.ax.plot(future_timestamps, predictions, 'r--', label='Predictions', marker='s')
        self.ax.set_title("Real-time Data with Predictions")
        self.ax.set_xlabel("Time")
        self.ax.set_ylabel("Value")
        self.ax.legend()
        self.ax.tick_params(axis='x', labelsize=8)
        self.fig.tight_layout()
        self.canvas.draw()

    def update_predictions(self, predictions, error=None):
        """
        Update the prediction display.
        
        Shows:
        - Next predicted value
        - Mean squared error (if available)
        
        Args:
            predictions (pd.Series): Series of predictions with timestamps
            error (float, optional): Mean squared error of predictions
        """
        if predictions is not None:
            self.prediction_label.config(text=f"Next Prediction: {predictions.iloc[-1]:.2f}")
        if error is not None:
            self.error_label.config(text=f"Error: {error:.4f}")

    def run(self):
        """
        Start the GUI main loop.
        
        This method should be called to start the application.
        """
        self.root.mainloop() 