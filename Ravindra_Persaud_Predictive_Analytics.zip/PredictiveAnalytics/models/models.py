import numpy as np
import pandas as pd
from statsmodels.tsa.arima.model import ARIMA
from sklearn.metrics import mean_squared_error, mean_absolute_error
from typing import Tuple, Optional, Dict, Any

class PredictionModel:
    def __init__(self, learning_rate: float = 0.01, n_iterations: int = 1000):
        """Initialize the prediction model with gradient descent parameters."""
        self.learning_rate = learning_rate
        self.n_iterations = n_iterations
        self.weights = None
        self.bias = None
        self.arima_model = None

    def train_gradient_descent(self, X: np.ndarray, y: np.ndarray) -> Dict[str, Any]:
        """
        Train the model using gradient descent.
        
        Args:
            X: Feature matrix
            y: Target values
            
        Returns:
            Dictionary containing training history and final parameters
        """
        n_samples, n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0
        history = {'loss': []}

        for _ in range(self.n_iterations):
            # Forward pass
            y_pred = np.dot(X, self.weights) + self.bias
            
            # Calculate loss
            loss = np.mean((y_pred - y) ** 2)
            history['loss'].append(loss)
            
            # Calculate gradients
            dw = (2/n_samples) * np.dot(X.T, (y_pred - y))
            db = np.mean(y_pred - y)
            
            # Update parameters
            self.weights -= self.learning_rate * dw
            self.bias -= self.learning_rate * db

        return history

    def predict_gradient_descent(self, X: np.ndarray) -> np.ndarray:
        """
        Make predictions using the trained gradient descent model.
        
        Args:
            X: Feature matrix
            
        Returns:
            Array of predictions
        """
        if self.weights is None:
            raise ValueError("Model has not been trained yet")
        return np.dot(X, self.weights) + self.bias

    def train_arima(self, data: pd.Series, order: Tuple[int, int, int] = (1, 1, 1)) -> Dict[str, Any]:
        """
        Train an ARIMA model on time series data.
        
        Args:
            data: Time series data
            order: ARIMA order (p, d, q)
            
        Returns:
            Dictionary containing model summary and metrics
        """
        try:
            # Fit ARIMA model
            self.arima_model = ARIMA(data, order=order)
            results = self.arima_model.fit()
            
            # Calculate predictions
            predictions = results.predict(start=0, end=len(data)-1)
            
            # Calculate metrics
            mse = mean_squared_error(data, predictions)
            mae = mean_absolute_error(data, predictions)
            
            return {
                'summary': results.summary(),
                'mse': mse,
                'mae': mae,
                'aic': results.aic,
                'bic': results.bic
            }
            
        except Exception as e:
            print(f"Error training ARIMA model: {e}")
            return {}

    def predict_arima(self, steps: int = 1) -> Optional[pd.Series]:
        """
        Make predictions using the trained ARIMA model.
        
        Args:
            steps: Number of steps to forecast
            
        Returns:
            Series of predictions or None if prediction fails
        """
        if self.arima_model is None:
            raise ValueError("ARIMA model has not been trained yet")
            
        try:
            forecast = self.arima_model.forecast(steps=steps)
            return forecast
            
        except Exception as e:
            print(f"Error making ARIMA predictions: {e}")
            return None

    def update_bayesian(self, prior_mean: np.ndarray, prior_cov: np.ndarray,
                       X: np.ndarray, y: np.ndarray, noise_var: float = 0.1) -> Tuple[np.ndarray, np.ndarray]:
        """
        Update model parameters using Bayesian inference.
        
        Args:
            prior_mean: Prior mean of parameters
            prior_cov: Prior covariance matrix
            X: Feature matrix
            y: Target values
            noise_var: Assumed noise variance
            
        Returns:
            Tuple of (posterior mean, posterior covariance)
        """
        # Calculate posterior parameters
        posterior_cov = np.linalg.inv(
            np.linalg.inv(prior_cov) + (1/noise_var) * np.dot(X.T, X)
        )
        
        posterior_mean = np.dot(
            posterior_cov,
            np.dot(np.linalg.inv(prior_cov), prior_mean) +
            (1/noise_var) * np.dot(X.T, y)
        )
        
        return posterior_mean, posterior_cov 