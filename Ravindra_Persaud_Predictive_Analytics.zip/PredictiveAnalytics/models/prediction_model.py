"""
SimplePredictionModel: A basic linear regression model for time series prediction.

This module implements a simple prediction model using scikit-learn's LinearRegression
for making time series predictions. It handles basic data preparation, model training,
and prediction generation.

Example usage:
    >>> model = SimplePredictionModel()
    >>> model.train(data)
    >>> predictions = model.predict(future_timestamps)
"""

import numpy as np
from sklearn.linear_model import LinearRegression
import pandas as pd

class SimplePredictionModel:
    """
    A simple prediction model using linear regression for time series data.
    
    This class provides functionality for:
    - Preparing time series data for training
    - Training a linear regression model
    - Making predictions for future timestamps
    - Calculating prediction error
    
    Attributes:
        model (LinearRegression): The underlying scikit-learn linear regression model.
    """
    
    def __init__(self):
        """
        Initialize the prediction model.
        
        Creates a new LinearRegression model instance for making predictions.
        """
        self.model = LinearRegression()
        
    def prepare_data(self, data):
        """
        Prepare time series data for training or prediction.
        
        Args:
            data (pd.DataFrame): Input data containing time series values.
                               Should have a numeric column for values and
                               either a datetime index or sequential index.
        
        Returns:
            tuple: (timestamps, values) where:
                - timestamps: numpy array of numeric timestamps
                - values: numpy array of corresponding values
            Returns (None, None) if data preparation fails.
        """
        if not isinstance(data, pd.DataFrame):
            return None, None
            
        # Get numeric values from the first numeric column
        numeric_cols = data.select_dtypes(include=[np.number]).columns
        if len(numeric_cols) == 0:
            return None, None
            
        values = data[numeric_cols[0]].values
        
        # Convert timestamps to numeric values
        if isinstance(data.index, pd.DatetimeIndex):
            timestamps = data.index.astype(np.int64) // 10**9
        else:
            timestamps = np.arange(len(data))
        
        return timestamps.reshape(-1, 1), values
        
    def train(self, data):
        """
        Train the model with historical data.
        
        Args:
            data (pd.DataFrame): Historical data to train the model on.
                               Should be in the format expected by prepare_data().
        
        Returns:
            bool: True if training was successful, False otherwise.
        """
        X, y = self.prepare_data(data)
        if X is not None and y is not None:
            self.model.fit(X, y)
            return True
        return False
        
    def predict(self, future_timestamps):
        """
        Make predictions for future timestamps.
        
        Args:
            future_timestamps (pd.DatetimeIndex): Future timestamps to predict for.
        
        Returns:
            numpy.ndarray: Array of predicted values for the given timestamps.
                          Returns None if prediction fails.
        """
        if not isinstance(future_timestamps, pd.DatetimeIndex):
            return None
            
        timestamps = future_timestamps.astype(np.int64) // 10**9
        return self.model.predict(timestamps.reshape(-1, 1))
        
    def calculate_error(self):
        """
        Calculate the mean squared error of the model.
        
        Returns:
            float: The mean squared error of the model's predictions.
                   Returns None if error calculation fails.
        """
        if hasattr(self.model, 'predict'):
            X, y = self.prepare_data(self.current_data)
            if X is not None and y is not None:
                predictions = self.model.predict(X)
                return np.mean((predictions - y) ** 2)
        return None 