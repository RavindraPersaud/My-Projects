# Predictive Analytics Dashboard

A real-time predictive analytics application with data visualization and machine learning capabilities.

## Features

- Real-time data collection and visualization
- CSV and Excel file upload support
- Predictive modeling using linear regression
- Interactive GUI with matplotlib plots
- Error metrics and analysis

## Project Structure

```
predictive_analytics/
├── main.py                 # Main application entry point
├── gui/
│   └── gui.py             # GUI implementation
├── models/
│   └── prediction_model.py # Prediction model implementation
└── utils/
    └── data_collector.py  # Data collection utilities
```

## Requirements

- Python 3.8+
- pandas
- numpy
- matplotlib
- scikit-learn
- tkinter

## Installation

2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```

## Usage

1. Run the application:
   python main.py
   ```

2. Use the GUI to:
   - Upload data files
   - Start/stop data collection
   - Generate predictions
   - View visualizations

