"""
Predictive Analytics Dashboard Package.

This package provides a complete solution for:
- Real-time data collection and visualization
- Predictive modeling using linear regression
- Interactive data analysis through a graphical interface

The package is organized into the following modules:
- gui: Graphical user interface implementation
- models: Prediction model implementation
- utils: Utility functions for data handling
"""

__version__ = "1.0.0" 