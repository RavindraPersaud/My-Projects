import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
import numpy as np
from typing import Optional, Tuple, List
from matplotlib.figure import Figure
from matplotlib.animation import FuncAnimation

class DataVisualizer:
    def __init__(self, style: str = 'default'):
        """Initialize the visualizer with a plotting style."""
        plt.style.use(style)
        sns.set_theme()  # Use seaborn's default theme
        self.fig = None
        self.ax = None

    def plot_time_series(self, data: pd.DataFrame, title: str = "Time Series Data",
                        ylabel: str = "Value") -> Optional[Figure]:
        """
        Plot time series data.
        
        Args:
            data: DataFrame with time series data
            title: Plot title
            ylabel: Y-axis label
            
        Returns:
            Matplotlib figure object or None if plotting fails
        """
        try:
            self.fig, self.ax = plt.subplots(figsize=(10, 6))
            data.plot(ax=self.ax)
            self.ax.set_title(title)
            self.ax.set_xlabel("Time")
            self.ax.set_ylabel(ylabel)
            plt.tight_layout()
            return self.fig
            
        except Exception as e:
            print(f"Error plotting time series: {e}")
            return None

    def plot_predictions(self, actual: pd.Series, predicted: pd.Series,
                        title: str = "Actual vs Predicted Values") -> Optional[Figure]:
        """
        Plot actual vs predicted values.
        
        Args:
            actual: Actual values
            predicted: Predicted values
            title: Plot title
            
        Returns:
            Matplotlib figure object or None if plotting fails
        """
        try:
            self.fig, self.ax = plt.subplots(figsize=(10, 6))
            self.ax.plot(actual.index, actual.values, label='Actual', alpha=0.7)
            self.ax.plot(actual.index, predicted.values, label='Predicted', alpha=0.7)
            self.ax.set_title(title)
            self.ax.set_xlabel("Time")
            self.ax.set_ylabel("Value")
            self.ax.legend()
            plt.tight_layout()
            return self.fig
            
        except Exception as e:
            print(f"Error plotting predictions: {e}")
            return None

    def plot_error_metrics(self, errors: List[float], title: str = "Error Metrics") -> Optional[Figure]:
        """
        Plot error metrics over time.
        
        Args:
            errors: List of error values
            title: Plot title
            
        Returns:
            Matplotlib figure object or None if plotting fails
        """
        try:
            self.fig, self.ax = plt.subplots(figsize=(10, 6))
            self.ax.plot(errors)
            self.ax.set_title(title)
            self.ax.set_xlabel("Iteration")
            self.ax.set_ylabel("Error")
            plt.tight_layout()
            return self.fig
            
        except Exception as e:
            print(f"Error plotting error metrics: {e}")
            return None

    def plot_pca_results(self, transformed_data: pd.DataFrame,
                        explained_variance: float,
                        title: str = "PCA Results") -> Optional[Figure]:
        """
        Plot PCA results and explained variance.
        
        Args:
            transformed_data: PCA-transformed data
            explained_variance: Explained variance ratio
            title: Plot title
            
        Returns:
            Matplotlib figure object or None if plotting fails
        """
        try:
            self.fig, (self.ax1, self.ax2) = plt.subplots(1, 2, figsize=(15, 6))
            
            # Plot transformed data
            transformed_data.plot(ax=self.ax1)
            self.ax1.set_title("Transformed Data")
            self.ax1.set_xlabel("Time")
            self.ax1.set_ylabel("Principal Components")
            
            # Plot explained variance
            self.ax2.bar(range(1, len(transformed_data.columns) + 1),
                        [explained_variance] * len(transformed_data.columns))
            self.ax2.set_title("Explained Variance")
            self.ax2.set_xlabel("Principal Component")
            self.ax2.set_ylabel("Variance Ratio")
            
            plt.tight_layout()
            return self.fig
            
        except Exception as e:
            print(f"Error plotting PCA results: {e}")
            return None

    def create_animation(self, data: pd.DataFrame, interval: int = 100) -> Optional[FuncAnimation]:
        """
        Create an animated plot of the data.
        
        Args:
            data: DataFrame with time series data
            interval: Animation interval in milliseconds
            
        Returns:
            Matplotlib animation object or None if animation creation fails
        """
        try:
            self.fig, self.ax = plt.subplots(figsize=(10, 6))
            line, = self.ax.plot([], [])
            
            def init():
                self.ax.set_xlim(data.index[0], data.index[-1])
                self.ax.set_ylim(data.min().min(), data.max().max())
                return line,
            
            def animate(frame):
                line.set_data(data.index[:frame], data.iloc[:frame])
                return line,
            
            anim = FuncAnimation(self.fig, animate, init_func=init,
                               frames=len(data), interval=interval, blit=True)
            return anim
            
        except Exception as e:
            print(f"Error creating animation: {e}")
            return None

    def save_plot(self, filename: str, dpi: int = 300) -> bool:
        """
        Save the current plot to a file.
        
        Args:
            filename: Output filename
            dpi: Dots per inch
            
        Returns:
            True if save successful, False otherwise
        """
        try:
            if self.fig is None:
                print("No plot to save")
                return False
            self.fig.savefig(filename, dpi=dpi, bbox_inches='tight')
            return True
            
        except Exception as e:
            print(f"Error saving plot: {e}")
            return False 