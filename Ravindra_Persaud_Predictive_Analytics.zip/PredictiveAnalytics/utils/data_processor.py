import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from typing import Tuple, Optional

class DataProcessor:
    def __init__(self, n_components: int = 2):
        """Initialize the data processor with PCA configuration."""
        self.scaler = StandardScaler()
        self.pca = PCA(n_components=n_components)
        self.is_fitted = False

    def preprocess_data(self, data: pd.DataFrame) -> Optional[pd.DataFrame]:
        """
        Preprocess the data by handling missing values and scaling.
        
        Args:
            data: Input DataFrame
            
        Returns:
            Preprocessed DataFrame or None if preprocessing fails
        """
        try:
            # Handle missing values
            data = data.fillna(method='ffill').fillna(method='bfill')
            
            # Scale the data
            scaled_data = self.scaler.fit_transform(data)
            
            # Convert back to DataFrame
            processed_data = pd.DataFrame(
                scaled_data,
                columns=data.columns,
                index=data.index
            )
            
            return processed_data
            
        except Exception as e:
            print(f"Error preprocessing data: {e}")
            return None

    def apply_pca(self, data: pd.DataFrame) -> Tuple[Optional[pd.DataFrame], float]:
        """
        Apply PCA to reduce dimensionality.
        
        Args:
            data: Preprocessed DataFrame
            
        Returns:
            Tuple of (transformed data, explained variance ratio) or (None, 0) if PCA fails
        """
        try:
            # Fit and transform the data
            transformed_data = self.pca.fit_transform(data)
            
            # Calculate explained variance ratio
            explained_variance = np.sum(self.pca.explained_variance_ratio_)
            
            # Convert to DataFrame
            transformed_df = pd.DataFrame(
                transformed_data,
                columns=[f'PC{i+1}' for i in range(transformed_data.shape[1])],
                index=data.index
            )
            
            self.is_fitted = True
            return transformed_df, explained_variance
            
        except Exception as e:
            print(f"Error applying PCA: {e}")
            return None, 0.0

    def calculate_gradients(self, data: pd.DataFrame) -> Optional[pd.DataFrame]:
        """
        Calculate gradients for trend prediction.
        
        Args:
            data: Input DataFrame
            
        Returns:
            DataFrame with gradients or None if calculation fails
        """
        try:
            gradients = data.diff()
            return gradients
            
        except Exception as e:
            print(f"Error calculating gradients: {e}")
            return None

    def inverse_transform(self, transformed_data: pd.DataFrame) -> Optional[pd.DataFrame]:
        """
        Inverse transform PCA results back to original space.
        
        Args:
            transformed_data: PCA-transformed DataFrame
            
        Returns:
            Original space DataFrame or None if transformation fails
        """
        if not self.is_fitted:
            print("PCA has not been fitted yet")
            return None
            
        try:
            # Inverse transform PCA
            original_data = self.pca.inverse_transform(transformed_data)
            
            # Inverse transform scaling
            original_data = self.scaler.inverse_transform(original_data)
            
            # Convert to DataFrame
            original_df = pd.DataFrame(
                original_data,
                columns=self.scaler.feature_names_in_,
                index=transformed_data.index
            )
            
            return original_df
            
        except Exception as e:
            print(f"Error inverse transforming data: {e}")
            return None 