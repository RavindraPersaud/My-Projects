"""
Utility modules for the Predictive Analytics Dashboard.

This package provides utility functions for:
- Data collection and generation
- Data processing and transformation
- Visualization and plotting

Modules:
- data_collector: For generating and collecting time series data
- visualizer: For creating and updating visualizations
- data_processor: For processing and transforming data
"""

__version__ = "1.0.0" 