"""
DataCollector: A utility class for generating and collecting time series data.

This module provides functionality for:
- Generating synthetic time series data
- Simulating real-time data collection
- Creating test datasets for the predictive analytics application

Example usage:
    >>> collector = DataCollector()
    >>> data = collector.generate_data(num_points=10)
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os
from typing import Optional

class DataCollector:
    """
    A utility class for generating and collecting time series data.
    
    This class provides methods for:
    - Generating synthetic time series data
    - Creating test datasets with various patterns
    - Simulating real-time data collection
    
    The generated data can be used for:
    - Testing the prediction model
    - Demonstrating the application
    - Development and debugging
    """
    
    def __init__(self, data_dir: str = "data"):
        """
        Initialize the data collector with a data directory.
        
        Args:
            data_dir (str): Directory to save and load data
        """
        self.data_dir = data_dir
        if not os.path.exists(data_dir):
            os.makedirs(data_dir)
        self.base_value = 100
        self.noise_level = 5
        self.trend = 0.1

    def generate_data(self, num_points: int = 100) -> pd.DataFrame:
        """
        Generate random data points for demonstration.
        
        Args:
            num_points: Number of data points to generate
            
        Returns:
            DataFrame containing the generated data
        """
        # Generate timestamps
        end_time = datetime.now()
        start_time = end_time - timedelta(hours=24)  # Last 24 hours
        timestamps = pd.date_range(start=start_time, end=end_time, periods=num_points)
        
        # Generate random values with some trend and noise
        trend = np.linspace(0, 10, num_points)
        noise = np.random.normal(0, 1, num_points)
        values = trend + noise
        
        # Create DataFrame
        df = pd.DataFrame({
            'value': values
        }, index=timestamps)
        
        return df

    def save_data(self, df: pd.DataFrame, filename: str) -> bool:
        """
        Save data to a CSV file.
        
        Args:
            df: DataFrame to save
            filename: Name of the file to save to
            
        Returns:
            True if save was successful, False otherwise
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            df.to_csv(filepath)
            return True
        except Exception as e:
            print(f"Error saving data: {e}")
            return False

    def load_data(self, filename: str) -> Optional[pd.DataFrame]:
        """
        Load data from a saved CSV file.
        
        Args:
            filename: Name of the file to load
            
        Returns:
            DataFrame containing the loaded data or None if load fails
        """
        try:
            filepath = os.path.join(self.data_dir, filename)
            df = pd.read_csv(filepath, index_col=0, parse_dates=True)
            return df
        except Exception as e:
            print(f"Error loading data: {e}")
            return None

    def generate_seasonal_data(self, num_points=24, seasonality=12):
        """
        Generate data with seasonal patterns.
        
        Args:
            num_points (int): Total number of points to generate
            seasonality (int): Length of the seasonal cycle
            
        Returns:
            pd.DataFrame: Generated data with seasonal patterns
        """
        timestamps = pd.date_range(end=datetime.now(), periods=num_points, freq='H')
        base = self.base_value + np.arange(num_points) * self.trend
        seasonal = 10 * np.sin(2 * np.pi * np.arange(num_points) / seasonality)
        noise = np.random.normal(0, self.noise_level, num_points)
        
        values = base + seasonal + noise
        
        return pd.DataFrame({'value': values}, index=timestamps)
        
    def generate_trend_data(self, num_points=24, trend_factor=0.5):
        """
        Generate data with a specific trend.
        
        Args:
            num_points (int): Number of points to generate
            trend_factor (float): Strength of the trend
            
        Returns:
            pd.DataFrame: Generated data with specified trend
        """
        timestamps = pd.date_range(end=datetime.now(), periods=num_points, freq='H')
        trend = np.arange(num_points) * trend_factor
        values = self.base_value + trend + np.random.normal(0, self.noise_level, num_points)
        
        return pd.DataFrame({'value': values}, index=timestamps) 