"""
Main entry point for the Predictive Analytics Dashboard.

This module initializes and runs the main application window.
It creates the Tkinter root window and starts the PredictiveAnalyticsGUI.

Example usage:
    python main.py
"""

import tkinter as tk
from gui.gui import PredictiveAnalyticsGUI

def main():
    """
    Main entry point for the application.
    
    Creates the main window and starts the GUI application.
    This function:
    1. Creates the Tkinter root window
    2. Initializes the PredictiveAnalyticsGUI
    3. Starts the main event loop
    
    The application will run until the window is closed.
    """
    # Create the main window
    root = tk.Tk()
    
    # Create and run the GUI
    app = PredictiveAnalyticsGUI(root)
    app.run()

if __name__ == "__main__":
    # Start the application when this file is run directly
    main() 